# Pyarmor 9.2.0 (trial), 000000, 2025-11-24T14:48:50.552420
from .pyarmor_runtime import __pyarmor__
