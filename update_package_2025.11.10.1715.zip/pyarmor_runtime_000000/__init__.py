# Pyarmor 9.2.0 (trial), 000000, 2025-11-10T17:15:11.344027
from .pyarmor_runtime import __pyarmor__
